window.g = { 
    AXIOS_TIMEOUT: 10000, 
    ApiUrl: 'http://123.207.11.116:5488', // ios下载服务, 
    Apis: 'https://kpsqxxxyyy.yuhezg.com', // 后端服务, 
  }